export default interface BulletSnapshot {
	readonly id: number;
	readonly x: number;
	readonly y: number;
};
