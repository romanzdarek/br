export default interface GranadeSnapshot {
	readonly x: number;
	readonly y: number;
	readonly a: number;
	//obove ground
	readonly b: number;
	//type
	readonly t: string;
};
