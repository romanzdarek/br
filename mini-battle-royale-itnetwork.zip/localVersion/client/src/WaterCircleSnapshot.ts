export default interface WaterCircleSnapshot {
	x: number;
	y: number;
};
