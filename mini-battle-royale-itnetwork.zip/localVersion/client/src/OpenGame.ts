export default interface OpenGame {
	readonly index: number;
	readonly name: string;
};
