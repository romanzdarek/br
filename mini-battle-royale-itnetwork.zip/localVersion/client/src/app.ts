import { Controller } from './Controller';
Controller.run();
console.log('Version: 1.0.0');
