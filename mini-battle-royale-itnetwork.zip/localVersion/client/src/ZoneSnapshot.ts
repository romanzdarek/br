export default interface ZoneSnapshot {
	//in
	iX: number;
	iY: number;
	iR: number;
	//out
	oX: number;
	oY: number;
	oR: number;
	//delay
	d: number;
};
