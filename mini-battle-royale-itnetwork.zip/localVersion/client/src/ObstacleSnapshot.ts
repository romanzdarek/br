export default interface ObstacleSnapshot {
	//id
	i: number;
	//opacity
    o: number;
    //type
    t: string;
};
