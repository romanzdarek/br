export default interface SmokeCloudSnapshot {
	readonly x: number;
	readonly y: number;
	//size
	readonly s: number;
	//opacity
	readonly o: number;
};
