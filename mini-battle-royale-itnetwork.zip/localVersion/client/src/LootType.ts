export enum LootType {
	Pistol,
	Machinegun,
	Shotgun,
	Rifle,
	Hammer,
	RedAmmo,
	GreenAmmo,
	BlueAmmo,
	OrangeAmmo,
	Vest,
	Medkit,
	Granade,
	Smoke,
	Scope2,
	Scope4,
	Scope6
}
