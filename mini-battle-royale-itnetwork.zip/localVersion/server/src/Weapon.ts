export enum Weapon {
	Empty,
	Hand,
	Pistol,
    Machinegun,
    Shotgun,
    Rifle,
    Hammer,
    Granade,
    Smoke,
    Medkit
}
